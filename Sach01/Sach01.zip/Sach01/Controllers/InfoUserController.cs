﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Sach01.Controllers
{
    public class InfoUserController : Controller
    {
        // GET: InfoUser
        public ActionResult Index()
        {
            return View();
        }
    }
}